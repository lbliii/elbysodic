Elbysodic — Faces & Threads v1

52 original SVG icons: 33 product concepts and 19 utilities.
24-unit viewBox; 1.75-unit rounded strokes; currentColor.

svg/ contains standalone SVGs for design tools and individual use.
The sprite preserves elbysodic-icon-* IDs for <use> integration.
For inline decorative UI, hide the SVG from assistive technology
and label the owning control. Use 16, 20, or 24 CSS pixels.

This is an export snapshot of src/elbysodic/web/static/icons/sidebar.svg.
Edit that canonical sprite first; regenerate this archive after artwork changes.
See design/icons/README.md in the repository for the inventory and full contract.
